const calculateTax = (subtotal, taxrate) => {
    return subtotal * taxrate;
}

module.exports = {
    calculateTax
}
